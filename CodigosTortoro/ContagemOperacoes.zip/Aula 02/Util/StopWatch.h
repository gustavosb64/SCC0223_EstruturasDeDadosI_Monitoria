#ifndef STOPWATCH_H
#define STOPWATCH_H

#include <stdio.h>
#include <time.h>

double getExecutionTime(time_t startTime, time_t endTime);

#endif // STOPWATCH
