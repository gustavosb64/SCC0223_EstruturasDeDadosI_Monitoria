#ifndef NUMBERLIST_H
#define NUMBERLIST_H

typedef struct _numberVector_t
{
    int* numbers;
    int vectorSize;
} numberVector_t;

#endif //NUMBERLIST_H
