Arquivo zip gerado em: 25/08/2022 21:56:03 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Exercício 01 - Pontos Cartesianos