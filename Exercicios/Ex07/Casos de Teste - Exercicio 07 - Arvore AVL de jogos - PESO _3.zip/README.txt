Arquivo zip gerado em: 05/10/2022 15:02:56 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Exercício 07 - Árvore AVL de jogos - PESO *3