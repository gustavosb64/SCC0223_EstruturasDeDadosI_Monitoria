Arquivo zip gerado em: 06/09/2022 00:28:42 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Exercício 02 - Catálogo de jogos