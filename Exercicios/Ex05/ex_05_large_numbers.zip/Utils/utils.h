#ifndef UTILS_H
#define UTILS_H


char* read_word();

char* boolean_print(int value);


#endif