Arquivo zip gerado em: 26/09/2022 16:42:34 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Exercício 04 - Pilha de cartas